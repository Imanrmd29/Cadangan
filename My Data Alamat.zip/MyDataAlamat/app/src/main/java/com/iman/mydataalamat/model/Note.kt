package com.iman.mydataalamat.model

data class Note(var fileName: String, var noteText: String)